// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyC_OgD_7sjSDDyUjCMvhSZDKCGDyB3p4tA",
    authDomain: "react30-75ed7.firebaseapp.com",
    databaseURL: "https://react30-75ed7.firebaseio.com",
    projectId: "react30-75ed7",
    storageBucket: "react30-75ed7.appspot.com",
    messagingSenderId: "485550623068",
    appId: "1:485550623068:web:29a5a1437106ef8b42d999",
    measurementId: "G-5EBTZ6MBPW"
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
