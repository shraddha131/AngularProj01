import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-master',
  templateUrl: './company-master.component.html',
  styleUrls: ['./company-master.component.css']
})
export class CompanyMasterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
