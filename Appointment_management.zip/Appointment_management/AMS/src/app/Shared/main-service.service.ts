import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';



import { Service } from './service.model';
import { Employee } from './employee.model';
import{ ManageSlots } from './manage-appointment.model';
import { Login } from './login.model';

import { from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MainServiceService {

  selectedService: Service  //
  allServices: Service[];


  selectedEmployee:Employee  //
  allEmployee : Employee[];

  selectedSlots: ManageSlots  //
  slots: ManageSlots[];

  selectedUser : Login   //
  users : Login[];

  readonly servicesURL = 'http://localhost:3000/service'
  readonly employeeURL = 'http://localhost:3000/employee'
  readonly manageAppURL = 'http://localhost:3000/manageAppointment'
  readonly availableSlotURL = 'http://localhost:3000/manageAppointment/slots'
  readonly dateURL = 'http://localhost:3000/manageAppointment/slot'

  readonly adminURL = 'http://localhost:3000/admin/signin'
  readonly registerURL ='http://localhost:3000/admin'

  constructor(private http: HttpClient) { }



 /* *******************Services functions******************* */

getServicesList() {
  return this.http.get(this.servicesURL);
}
postServices(srv: Service) {
  return this.http.post(this.servicesURL, srv);
}
putServices(srv: Service) {
  return this.http.put(this.servicesURL + `/${srv._id}`, srv);
}

deleteServices(_id: string) {
  return this.http.delete(this.servicesURL + `/${_id}`);
}

updateService(srv: Service){
  return this.http.put(this.servicesURL + `/${srv.s_name}`, srv);
}

 /* *******************Services functions******************* */

getEmployeeList() {
  return this.http.get(this.employeeURL);
}

getEmployeeID(_id : String){
  return this.http.get(this.employeeURL + `/${_id}`)
}

postEmployee(emp: Employee) {
  return this.http.post(this.employeeURL, emp);
}
putEmployee(emp: Employee) {
  return this.http.put(this.employeeURL + `/${emp._id}`, emp);
}

deleteEmployee(_id: string) {
  return this.http.delete(this.employeeURL + `/${_id}`);
}

updateEmployee(emp: Employee){
  return this.http.put(this.employeeURL + `/${emp.emp_name}`, emp);
}

getEmployeeName(s_name:string){
  return this.http.get(this.employeeURL + `/service`+`/${s_name}`)
}

 /* *******************slots functions******************* */

getManageAppointment(){
  return this.http.get(this.manageAppURL);
}

checkSlots(emp_name:string,manage_date : string){
  return this.http.get(this.availableSlotURL +`/${emp_name}`+ `&` + `${manage_date}`);

}

postManageAppointment(mng : ManageSlots) {
  return this.http.post(this.manageAppURL,mng);
}

getDates(emp_name:string){
  return this.http.get(this.dateURL +`/${emp_name}`);
}



/*************************************************************** */

getSuperAdminList() {
  return this.http.get(this.adminURL);
}

getCustomer(){
  return this.http.get(this.registerURL);
}

getCustinfo(user_id : string){
  return this.http.get(this.registerURL +`/customer` + `/${user_id}`)
}

putCustomer(suprAdm: Login) {
  return this.http.put(this.registerURL + `/${suprAdm._id}`, suprAdm);
}

getLoogedInAdmin(id: string){
  return this.http.get(this.adminURL + `/user`+`/${id}`);
}

postUser(usr:Login){
  return this.http.post(this.registerURL,usr);
}


}