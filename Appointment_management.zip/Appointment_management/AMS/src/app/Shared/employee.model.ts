export class Employee {
  _id: string;
  emp_name: string;
  emp_phone:string;
  emp_edu:string;
  emp_email:string;
  emp_add:string;
  s_name:string;
}
