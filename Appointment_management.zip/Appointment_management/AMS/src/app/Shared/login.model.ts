export class Login {
 _id: String;
 user_id: String;
 email: String ;
 phone:String;
 password: String ;
}
