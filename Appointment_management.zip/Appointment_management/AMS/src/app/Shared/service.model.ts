export class Service {
    _id: String;
    s_name: String ;
    s_desc: String ;
}
