import { Service } from './service.model';

describe('Service', () => {
  it('should create an instance', () => {
    expect(new Service()).toBeTruthy();
  });
});
