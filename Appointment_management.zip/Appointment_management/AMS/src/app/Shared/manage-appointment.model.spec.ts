import { ManageAppointment } from './manage-appointment.model';

describe('ManageAppointment', () => {
  it('should create an instance', () => {
    expect(new ManageAppointment()).toBeTruthy();
  });
});
