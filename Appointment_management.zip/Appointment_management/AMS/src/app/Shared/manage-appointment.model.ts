export class ManageSlots {
    emp_name: String;
    manage_date:String;
    manage_session:String
    manage_timefrom:String ;
    fromampm : String;
    manage_timeTo : String ;
    toampm : String ;
    manage_interval : String ;
    slots:  String[] ;
}
