import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Login } from './login.model';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  selectedUser : Login;
  users : Login[];

  readonly baseURL = 'http://localhost:3000/admin'
  static user: any;

  constructor(private http : HttpClient) { }
  getSuperAdminList() {
    return this.http.get(this.baseURL);
  }
  getLoogedInAdmin(id: string){
    return this.http.get(this.baseURL + `/user`+`/${id}`);
  }
}
