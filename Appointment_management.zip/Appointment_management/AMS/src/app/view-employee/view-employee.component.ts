import { Component, OnInit } from '@angular/core';
import { MainServiceService } from '../Shared/main-service.service';
import { Employee } from '../Shared/employee.model';


@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.css']
})
export class ViewEmployeeComponent implements OnInit {
  selected: any;
  id: any;
  emp_details: any;
  emp: any;
  emp_id: string;
  date: any;
  newDate: any;
  DT: any;
  dates : String[];
  constructor(private mainServiceService : MainServiceService) { }
  details;
  ngOnInit(): void {
    this.emp_id= localStorage.getItem('emp_id')
    
    
    this.id=localStorage.getItem('emp_id')
    console.log(this.id)
    this.details={_id: "",emp_name: "",emp_phone:"",emp_edu:"",emp_email:"",emp_add:"",s_name:""}
    this.refreshDetails()

  }

  refreshDetails(){
    this.mainServiceService.getEmployeeID(this.emp_id).subscribe((res) => {
    this.emp_details = res as Employee[]; 
    console.log(this.emp_details['emp_name'])
    for(var i = 0; i < this.emp_details.length; i++)
{
  this.details=this.emp_details[0];
  console.log(this.details['emp_name'])

  this.mainServiceService.getDates(this.details['emp_name']).subscribe((res) =>{
    this.date = res;
    console.log("hi",this.date);

    // var dt = this.date
    // for(var i = 0;i<dt.length;i++) { 
    //   console.log(dt[i]);
    //   this.dates=dt[i];
   //}
   
    //   for (let i = 0; i <= this.date.length; i++) {
    //    console.log("SLT", this.date[i])
    //     this.DT=this.date[i]
    //  }
    // this.DT=this.date.forEach(function (value) {
    //   console.log(value);      
    // });
  })
}


  });

    // this.mainServiceService.getDates(this.details['emp_name']).subscribe((res) =>{
    //   this.date = res;
    //   console.log("hi",this.date);
    // })
    // console.log(Employee)

  }

  slots(date:any){
    console.log(date);

  }


}
