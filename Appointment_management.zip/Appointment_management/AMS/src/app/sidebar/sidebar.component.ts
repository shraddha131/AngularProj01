import { Component, OnInit } from '@angular/core';
import { MainServiceService } from '../Shared/main-service.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Login } from '../Shared/login.model';
import { AuthService } from '../shared/auth.service'



function menu(){
  $("#menu-toggle, #menu-toggle2").click(function(e) {
    e.preventDefault();   
    $("#wrapper").toggleClass("toggled");
    $(".sidebar-nav").fadeToggle();
  });
  
}
function dropdown(){
  var dropdown = document.getElementsByClassName("dropdown-btn");
  var i;
  
  for (i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
    dropdownContent.style.display = "none";
    } else {
    dropdownContent.style.display = "block";
    }
    });
  }
 }





@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})




export class SidebarComponent implements OnInit {
id:any;
active: any;
LoggedInUser: Login[];
Luser:any;
  constructor(private formBuilder : FormBuilder ,public mainServiceService : MainServiceService,public _auth: AuthService ) { }

  ngOnInit() {
    menu();
   this.id ='5ea4532ac97e7d24cc203e69';
  console.log("ADMIN:",localStorage);

    if(localStorage._id==this.id){
          this.hide();        
    }
    else{
      this.hide2();
    }

}


  selectedTab = "Tab1";

  makeActive(tab: string) {
    this.selectedTab = tab;
  }


 hide()
  {
    document.getElementById('hide2').hidden = true;
  }

  hide2()
  {
    document.getElementById('hide3').hidden = true;
    document.getElementById('hide4').hidden = true;

    document.getElementById('hide5').hidden = true;

    document.getElementById('hide6').hidden = true;
    document.getElementById('hide7').hidden = true;


  }
  refreshuser()
{
 
  this.mainServiceService.getLoogedInAdmin(this.Luser).subscribe((res) => {
    this.LoggedInUser = res as Login[];
    console.log(this.LoggedInUser); 
});
}

  
} 
