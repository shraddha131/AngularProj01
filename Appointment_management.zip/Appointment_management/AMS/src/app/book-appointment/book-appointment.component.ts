import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MainServiceService } from '../Shared/main-service.service';
import { Service } from '../Shared/service.model';

@Component({
  selector: 'app-book-appointment',
  templateUrl: './book-appointment.component.html',
  styleUrls: ['./book-appointment.component.css']
})
export class BookAppointmentComponent implements OnInit {

BookAppointment:FormGroup;
submitted = false;
pattern:any;
Service:any;
  constructor(private formBuilder : FormBuilder,public mainServiceService : MainServiceService  ) {}

  ngOnInit() {


    this.pattern = "[7-9]{1}[0-9]{9}"

    this.BookAppointment = this.formBuilder.group({
      cust_name:['',Validators.required],
      cust_phone:['',[Validators.required,Validators.pattern]],
      cust_email:['',[Validators.required,Validators.email]],
      cust_city:['',Validators.required],
      s_name:['',Validators.required],
      cust_specialist:['',Validators.required],
      cust_date:['',Validators.required],
      cust_slot:['',Validators.required]

    });

    this.refreshServiceList();
  }

 

get f(){ return this.BookAppointment.controls; }



  onSubmit() {
    this.submitted = true;
    if (this.BookAppointment.invalid) {
        return;
    }
  }


refreshServiceList(){
      this.mainServiceService.getServicesList().subscribe((res) => {
      this.Service = this.mainServiceService.allServices = res as Service[];
      console.log(this.Service);
     });
  }




  onReset() {
    this.submitted = false;
    this.BookAppointment.reset();
}
}