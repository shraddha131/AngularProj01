import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MainServiceService } from '../Shared/main-service.service';
import { Service } from '../Shared/service.model';



@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css'],
  providers: [MainServiceService]
})

export class ServicesComponent implements OnInit {

  addService:FormGroup;
  submitted = false;
  addNewService : any;
  allservice:any;
  display='none';
  displayText = 'show-class';
  visible = true;
  selected:any;
  searchText;

  constructor(private formBuilder:FormBuilder , public mainServiceService : MainServiceService) { }

  ngOnInit() {

    this.addService = this.formBuilder.group({
      _id:[],
      s_name: ['', [Validators.required, Validators.minLength(3)]],
      s_desc: ['', [Validators.required, Validators.minLength(3) ]],
      
  });
  this.onReset();
  this.refreshServiceList();
  }

  get f() { return this.addService.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.addService.invalid) {
        return;
    }
    
    if(this.addService.value['_id'] == null){

      this.addNewService = { s_name: this.addService.value['s_name'], s_desc: this.addService.value['s_desc']}
      console.log("values",this.addNewService)
      
    this.mainServiceService.postServices(this.addNewService,).subscribe((res) => {
      console.log("NULLS",this.addService.value)
      this.onReset();
      this.refreshServiceList();
    });
    this.onReset()
    
  }

  else{
     this.mainServiceService.putServices(this.addService.value).subscribe((res) => {
       console.log("Demo : ",this.addService.value)
       this.onReset();
 
       this.refreshServiceList();
     });
     this.onReset()
     this.display='none';
   }
 

}

refreshServiceList() {
  this.mainServiceService.getServicesList().subscribe((res) => {
    this.mainServiceService.allServices = res as Service[];
  });
}


onEdit(srv: Service) {
  this.mainServiceService.selectedService = srv;
  this.selected = srv;
  this.display='block';
  this.f._id.setValue(this.selected['_id'], {
    onlySelf: true
  })
  this.f.s_name.setValue(this.selected['s_name'], {
    onlySelf: true
  })
  
  this.f.s_desc.setValue(this.selected['s_desc'], {
    onlySelf: true
  })
  
}



onDelete(_id: string) {
  if (confirm('Are you sure to delete this record ?') == true) {
   
    this.mainServiceService.deleteServices(_id).subscribe((res) => {
      this.refreshServiceList();
      this.onReset();
      // M.toast({ html: 'Deleted successfully', classes: 'rounded' });

    });
  }
}

openModalDialog(){
  this.display='block'; //Set block css
}

closeModalDialog(){
this.display='none'; //set none css after close dialog
}

 toggle() {
   this.visible = !this.visible;
  this.display = this.visible  ? 'block' : 'none';
}

onReset() {
    this.submitted = false;
    this.addService.reset();
}

}
