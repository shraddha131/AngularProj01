import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ForgetpasswordComponent } from './forgetpassword/forgetpassword.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { RegisterComponent } from './register/register.component';
import { AppointmentComponent } from './appointment/appointment.component';
import { BookAppointmentComponent } from './book-appointment/book-appointment.component';
import { ManageAppointmentComponent } from './manage-appointment/manage-appointment.component';
import { EmployeesComponent } from './employees/employees.component';
import { ServicesComponent } from './services/services.component';
import { CompanyMasterComponent } from './company-master/company-master.component';
import { UsersComponent } from './users/users.component';
import { SettingsComponent } from './settings/settings.component';
import { AddSlotsComponent } from './add-slots/add-slots.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';
import { AdminAppointmentComponent } from './admin-appointment/admin-appointment.component';
import { AuthGuard } from './Shared/auth.guard';
import { SidebarUserComponent } from './sidebar-user/sidebar-user.component';

const routes: Routes = [
  {path : '', component:LoginComponent},
    {path : 'forgetpassword',component:ForgetpasswordComponent},
    {path:'register',component:RegisterComponent},
    {path : 'Sidebar',canActivate:[AuthGuard],component:SidebarComponent,
    children :[{path:'appointment',component:AppointmentComponent},
               {path:'bookAppointment',component:BookAppointmentComponent},
               {path:'manageAppointment',component:ManageAppointmentComponent},
               {path:'emplyoees',component:EmployeesComponent},
               {path:'services',component:ServicesComponent},
               {path:'companyMaster',component:CompanyMasterComponent},
               {path:'users',component:UsersComponent},
               {path:'settings',component:SettingsComponent},
               {path:'AddSlot',component:AddSlotsComponent},
               {path:'AddEmployee',component:AddEmployeeComponent},
               {path:'ViewEmplyoee',component:ViewEmployeeComponent},
               {path: 'AdminAppointment',component:AdminAppointmentComponent}]
    }

  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  
 }
