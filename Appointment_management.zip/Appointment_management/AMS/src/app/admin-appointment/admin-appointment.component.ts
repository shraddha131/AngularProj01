import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MainServiceService } from '../Shared/main-service.service';
import { Service } from '../Shared/service.model';
import { Login } from '../Shared/login.model';
import { Employee } from '../Shared/employee.model';
import { ManageSlots } from '../Shared/manage-appointment.model';

@Component({
  selector: 'app-admin-appointment',
  templateUrl: './admin-appointment.component.html',
  styleUrls: ['./admin-appointment.component.css']
})
export class AdminAppointmentComponent implements OnInit {

  AdminBookAppointment:FormGroup;
  submitted=false;
  pattern: string;
  Service: any;
  Cust: any;
  selected: any;
Login : Login[];
  service_name: any;
  emp_arr: any;
  emp_arrr:string[];
  user_name: any;
  custdetails: Login[];
  custdel: any;
  date: any;
  selectEmp : any;
  dateslt: (event: any) => void;
  manage_date: any;
  emp_name: any;
  availableslts:any;
  availableslt: any;
  newSlots: any;
  selectedSlot: any;
  AllFeild: boolean;
  dayFinished: any;
  addNewAppointment:any;
  constructor(private formBuilder : FormBuilder,public mainServiceService :MainServiceService) { }

  ngOnInit(): void {
    this.pattern = "[7-9]{1}[0-9]{9}"

    this.AdminBookAppointment = this.formBuilder.group({
      cust_name:['',Validators.required],
      cust_phone:['',[Validators.required,Validators.pattern]],
      cust_email:['',[Validators.required,Validators.email]],
      s_name:['',Validators.required],
      cust_specialist:['',Validators.required],
      cust_date:[''],
      cust_slot : ['']
    });
    this.refreshServiceList();
    this.refreshCustName();

  }

  selectService(event:any){
    this.service_name = event.target.value;
    console.log("hii",this.service_name);
    this.mainServiceService.getEmployeeName(this.service_name).subscribe((res) => {
      this.emp_arr=res;
      console.log(res);
      for (var i = 0; i < this.emp_arr.length; i++) {
          console.log(this.emp_arr[i])
      }
  });
}

selectedemp(emp:any){
  this.selectEmp = emp.target.value;
  console.log("hello",this.selectEmp);  

}
  
selectdate(event:any){
  this.manage_date=event.target.value;
  console.log(this.manage_date)
  console.log(this.selectEmp)
  this.emp_name = this.selectEmp;
  
  this.mainServiceService.checkSlots(this.emp_name,this.manage_date).subscribe((res)=>{
    this.availableslt =  this.mainServiceService.slots = res as ManageSlots[];
    let SLT=[];
    for (let i = 0; i <= this.availableslt.length-1; i++) {
     SLT.push( this.availableslt[i]['slots'])
   }
    
   this.newSlots= Array.prototype.concat.apply([],SLT) //all available_slots conatination
   console.log("SLT", SLT)
   console.log("NEWSLT", this.newSlots)
  });
  
}




names(user_id : any){
  this.user_name = user_id.target.value;
  console.log(this.user_name);

  this.mainServiceService.getCustinfo(this.user_name).subscribe((res)=>{
    this.custdetails = this.mainServiceService.users = res as Login[];

    for (var i = 0; i < this.custdetails.length; i++) {
      this.custdel = this.custdetails[i];
      console.log("demo",this.custdetails[i])
  }
console.log(this.custdel['phone'])

    this.f.cust_phone.setValue(this.custdel['phone'], {
      onlySelf: true
    })
    this.f.cust_email.setValue(this.custdel['email'], {
      onlySelf: true
    })

    console.log(this.custdetails)
  });
}


  
  get f(){ return this.AdminBookAppointment.controls; }
 
  onSubmit() {
    this.submitted = true;
    if (this.AdminBookAppointment.invalid) {
        return;
    }
            alert('SUCCESS!! :-)\n\n' );
            if(this.AdminBookAppointment.value['_id'] == null){

              this.addNewAppointment = { 
              cust_name: this.AdminBookAppointment.value['cust_name'], 
              cust_phone: this.AdminBookAppointment.value['cust_phone'],
              cust_email: this.AdminBookAppointment.value['cust_email'], 
              s_name: this.AdminBookAppointment.value['s_name'],
              cust_specialist: this.AdminBookAppointment.value['cust_specialist'], 
              cust_date: this.AdminBookAppointment.value['cust_date'],
              cust_slot : this.AdminBookAppointment.value['cust_slot']}
              
              console.log("values",this.addNewAppointment)
              
              this.mainServiceService.postEmployee(this.addNewAppointment,).subscribe((res) => {
              console.log(this.AdminBookAppointment.value)
            });
        
            this.onReset()
             }
          else{
             this.mainServiceService.putServices(this.AdminBookAppointment.value).subscribe((res) => {
               console.log(this.AdminBookAppointment.value)
               this.onReset();
             });
             this.onReset()
           }

  }
    
refreshServiceList(){
  this.mainServiceService.getServicesList().subscribe((res) => {
  this.Service = this.mainServiceService.allServices = res as Service[];
  console.log(this.Service);
 });
}

refreshCustName(){
  this.mainServiceService.getCustomer().subscribe((res)=>{
    this.Cust = this.mainServiceService.users = res as Login[];
console.log(this.Cust)
  });
}

onSelect(suprAdm : Login){
  this.selected=suprAdm;
  console.log("hii",this.selected)
}

slotSelected(slot: any){
  console.log(slot);
 this.selectedSlot = slot;
 this.AllFeild = false;
}

isActiveSlot(slt: any){
 return this.selectedSlot === slt;
}

isActive(item) {  
    return this.selected === item;
};

test(day){
   this.dayFinished = day+1;
  this.dayFinished -= 1;
}

Disabledemo(eg: String,i: string){

}



onReset() {
      this.submitted = false;
      this.AdminBookAppointment.reset();
  }


  
  }


