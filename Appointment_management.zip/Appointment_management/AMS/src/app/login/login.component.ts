import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../shared/auth.service'
import { HttpErrorResponse } from '@angular/common/http';
import { MainServiceService } from '../Shared/main-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[MainServiceService,AuthService]
})
export class LoginComponent implements OnInit {
  semail:string;
  spass: string;
  loginForm: FormGroup;
  submitted = false;
  error= 'none';
  abc: any;
   xyz: any;
   demo: any;
  admin: any;
  constructor(private route:ActivatedRoute , private router:Router , private formBuilder: FormBuilder , 
    public mainServiceService : MainServiceService , private _auth: AuthService ) { }
  
  ngOnInit() {
    this.loginForm = this.formBuilder.group({


      user_id: ['', [Validators.required, Validators.minLength(5)]],

      password: ['', [Validators.required, Validators.minLength(6)]]


  });
  }
  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;
    
    if (this.loginForm.invalid) {
        return;
    }
    else{
  
      this._auth.loginUser(this.loginForm.value)
      .subscribe(
        res => {
          this.error="none"
           this.demo = res
          //  this.admin = '5ea4532ac97e7d24cc203e69';
          // console.log("demo",this.demo['_id'])
          // if(this.demo['_id']==this.admin)
          // {
          // localStorage.setItem('token', res.token)
          // localStorage.setItem('_id', res._id)
          // this.router.navigate(['Sidebar/appointment'],{relativeTo:this.route})
          // }
          // else
          // {
          localStorage.setItem('token', res.token)
          localStorage.setItem('_id', res._id)
          this.router.navigate(['Sidebar/appointment'],{relativeTo:this.route})
          //}
        },
        err => {
         
          if( err instanceof HttpErrorResponse ) {
            if (err.status === 401) {
              this.router.navigate([''])
              console.log("Hello");
              this.error="block"
            }
          }
        }
      )
   
    
  }
    
  
  }

}
