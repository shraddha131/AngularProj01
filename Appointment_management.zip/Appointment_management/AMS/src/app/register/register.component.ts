import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MainServiceService } from '../Shared/main-service.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers:[MainServiceService]
})
export class RegisterComponent implements OnInit {

  registerUser : FormGroup;
  submitted = false;
  emailPattern: string;


  constructor(private formBuilder : FormBuilder ,public mainServiceService : MainServiceService , 
    public router : Router,private route : ActivatedRoute) { }

  ngOnInit() {

    this.emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
    this.registerUser = this.formBuilder.group({
      _id:[],
      user_id:['',[Validators.required,Validators.minLength(3)]],
      phone:['',[Validators.required,Validators.minLength(10)]],
      email:['', [Validators.required, Validators.email,Validators.pattern(this.emailPattern)]],
      password:['',[Validators.required,Validators.minLength(3)]],
    });

  }
  get f() { return this.registerUser.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.registerUser.invalid) {
        return;
    }
    
    else
    {

    this.submitted = true;
    this.mainServiceService.postUser(this.registerUser.value).subscribe((res) => {
      console.log(this.registerUser.value)
      alert("successfull and login Again!!");
  });
  this.onReset();
}
}

onReset() {
  this.submitted = false;
  this.registerUser.reset();
  
}


}
