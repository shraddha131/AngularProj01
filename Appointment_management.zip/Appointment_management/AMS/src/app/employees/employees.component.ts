import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MainServiceService } from '../Shared/main-service.service';
import { Employee } from '../Shared/employee.model';
import { Service } from '../Shared/service.model';
import {ActivatedRoute,Router } from '@angular/router';
import { idLocale } from 'ngx-bootstrap';
@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css'],
  providers:[MainServiceService]
})
export class EmployeesComponent implements OnInit {
  editEmployee : FormGroup;
  submitted = false;

  
  selected:any;
  Employee: Employee[];
  emp_name: any;
  _id: any;
  emp_phone: any;
  emp_edu: any;
  emp_email: any;
  emp_addr: any;
  s_name: any;
  emailPattern: string;
  Service: Service[];
  display= 'none';
  value: void;
  setEmp: any;
  empid: void;
  storage: any;

  constructor(private formBuilder : FormBuilder ,public mainServiceService : MainServiceService , public router : Router,private route : ActivatedRoute) { }




  ngOnInit() {
    this.refreshEmployeeList();
    this.emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";

    this.editEmployee = this.formBuilder.group({
      _id:[],
      emp_name:['',[Validators.required,Validators.minLength(3)]],
      emp_phone:['',[Validators.required,Validators.minLength(10)]],
      emp_edu:['',[Validators.required]],
      emp_email:['', [Validators.required, Validators.email,Validators.pattern(this.emailPattern)]],
      emp_addr:['',[Validators.required,Validators.minLength(3)]],
      s_name:['',[Validators.required,Validators.minLength(3)]]
    });
 this.refreshServiceList();

  }

  get f() { return this.editEmployee.controls; }

  refreshEmployeeList() {
    this.mainServiceService.getEmployeeList().subscribe((res) => {
     this.Employee = this.mainServiceService.allEmployee = res as Employee[];
    });
  }
  
  refreshServiceList(){
    this.mainServiceService.getServicesList().subscribe((res) => {
    this.Service = this.mainServiceService.allServices = res as Service[];
    console.log(this.Service);
   });
}
  
  onEdit(emp: Employee) {
    this.selected = emp;
    this.f._id.setValue(this.selected['_id'], {
      onlySelf: true
    })
    this.f.emp_name.setValue(this.selected['emp_name'], {
      onlySelf: true
    })
    
    this.f.emp_phone.setValue(this.selected['emp_phone'], {
      onlySelf: true
    })

    this.f.emp_edu.setValue(this.selected['emp_edu'], {
      onlySelf: true
    })

    
    this.f.emp_email.setValue(this.selected['emp_email'], {
      onlySelf: true
    })
    
    this.f.emp_addr.setValue(this.selected['emp_addr'], {
      onlySelf: true
    })

    this.f.s_name.setValue(this.selected['s_name'],{
      onlySelf: true
    })
    
  }
  
  onSubmit() {
    this.submitted = true;
    this.mainServiceService.putEmployee(this.editEmployee.value).subscribe((res) => {
      console.log(this.editEmployee.value)
      this.refreshEmployeeList();
      this.closeModalDialog();
      alert("successfull");

  });
}
closeModalDialog(){
  this.display='none';
 }

  onDelete(_id: string) {
    console.log(_id);
    if (confirm('Are you sure to delete this record ?') == true) {
     
      this.mainServiceService.deleteEmployee(_id).subscribe((res) => {
        this.refreshEmployeeList();
      });
    }
  }


  
  onView(emp : Employee){
    this.selected=emp;
    console.log(this.selected)
    localStorage.setItem('emp_id',this.selected['_id']);

    this.router.navigateByUrl('/Sidebar/ViewEmplyoee');
  }
  

}  
