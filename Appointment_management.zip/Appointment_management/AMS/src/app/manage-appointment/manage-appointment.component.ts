import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Employee } from '../Shared/employee.model';
import {  ManageSlots } from '../Shared/manage-appointment.model';
import { MainServiceService } from '../Shared/main-service.service';
import { from } from 'rxjs';
import * as moment from 'moment';

const convertTime12to24 = (time12h: { split: (arg0: string) => [any, any]; }) => {
  const [time, modifier] = time12h.split(' ');

  let [hours, minutes] = time.split(':');

  if (hours === '12') {
    hours = '00';
  }

  if (modifier === 'PM') {
    hours = parseInt(hours, 10) + 12;
    minutes = parseInt(minutes);
  }else if(modifier === 'AM'){
    hours= parseInt(hours);
    minutes = parseInt(minutes);
  }

  return [hours, minutes];
}



@Component({
  selector: 'app-manage-appointment',
  templateUrl: './manage-appointment.component.html',
  styleUrls: ['./manage-appointment.component.css']
})
export class ManageAppointmentComponent implements OnInit {
  
  ManageAppointment : FormGroup;
  submitted = false;

  Employee: Employee[];
  model: any;
  ampm:any;
  slot:any[];
  ptrn='((1[0-2]|0?[1-9]):([0-5][0-9]))';
  a_From: any;
  times: any[];
  size: number;
  hours: any[];
  hour: any;
  min: any;
  a_To: any;
  from: any;
  From: any[];
  To: any[];
  time: any;
  interval: any;
  time_int: number;
  avilableSlots: any[];
  date: any;
  addNewSlot:any;
  finaldate: any;
  dateSelected: string;
  NgbDate: string;
  ManageSlots: ManageSlots[];
  name: any;
  checkSlot: any[];
  //ManageAppointment:ManageAppointment[]

  constructor(private formBuilder : FormBuilder,public mainServiceService : MainServiceService) { }

  ngOnInit() {
    this.ManageAppointment = this.formBuilder.group({
      id:[],
      emp_name:["",Validators.required],
      manage_date:['',Validators.required],
      manage_session:['',Validators.required],
      manage_timefrom:['',[Validators.required,Validators.pattern(this.ptrn)]],
      fromampm:['',Validators.required],
      manage_timeTo:['',[Validators.required,Validators.pattern(this.ptrn)]],
      toampm:['',Validators.required],
      manage_interval:['',Validators.required],
      slots:[]
    });
    this.refreshEmployeeList();
    this.refreshSlots();

  }

  get f() { return this.ManageAppointment.controls; }

  refreshEmployeeList() {
    this.mainServiceService.getEmployeeList().subscribe((res) => {
     this.Employee = this.mainServiceService.allEmployee = res as Employee[];
    });
  }

refreshSlots(){
  this.mainServiceService.getManageAppointment().subscribe((res)=>{
   this.ManageSlots = this.mainServiceService.slots = res as ManageSlots[];
  });
}

getName(e:any)
{
  this.name=e.target.value;
  console.log("name:",this.name);
}

  onSelect(e: any){
    this.date=e.target.value;
    console.log("date:",this.date);

  this.mainServiceService.checkSlots(this.name, this.date).subscribe((res) => {
    this.checkSlot = this.mainServiceService.slots = res as ManageSlots[];
     console.log("slots",this.checkSlot);
  });

  


  

}




  selectSession(e:any)
  {
    console.log(e.target.value);
    let tab=e.target.value;
    switch(tab)
    {
      case 'Morning':{
        this.ampm =['AM']
        this.f.manage_session.setValue('Morning',{
          onlySelf:true
        })        
      
      this.f.fromampm.setValue('AM', {
        onlySelf: true
      })
      this.f.toampm.setValue('AM', {
        onlySelf: true
      })
      break;
    }
    case'Afternoon':{
      this.ampm=['PM']
      this.f.manage_session.setValue('afternoon',{
        onlySelf:true
      })
      this.f.fromampm.setValue('PM', {
        onlySelf: true
      })
      this.f.toampm.setValue('PM', {
        onlySelf: true
      })
      break;
      }

      case 'Evening':{
        this.ampm=['PM']
        this.f.manage_session.setValue('Evening', {
          onlySelf: true
        })
        this.f.fromampm.setValue('PM', {
          onlySelf: true
        })
        this.f.toampm.setValue('PM', {
          onlySelf: true
        })
        break;
      }
      case 'All Day':{
        this.ampm=['AM','PM']
        this.f.manage_session.setValue('All Day', {
          onlySelf: true
        })
        break;
      }
      case 'default':{
        this.ampm=[]
      }
    }

    }
  

    slots(){
      console.log(this.ManageAppointment.value.manage_timefrom);
      this.a_From=this.ManageAppointment.value.manage_timefrom +" "+ this.ManageAppointment.value.fromampm;
      this.From=convertTime12to24(this.a_From);
      this.a_To=this.ManageAppointment.value.manage_timeTo +" "+ this.ManageAppointment.value.toampm;
      this.To=convertTime12to24(this.a_To);
      console.log(this.From);
      console.log(this.To);
      this.time=this.ManageAppointment.value['manage_interval'];
      this.interval = this.time.split(" ", 1); 
      this.time_int=parseInt(this.interval);
      console.log("converted: " , this.From[0],this.From[1] , this.To[0],this.To[1], this.time_int);
      this.avilableSlots= this.timegenerate(this.From[0],this.From[1] , this.To[0],this.To[1],this.time_int);
      console.log("Available slots", this.avilableSlots);
      //this.slot=this.avilableSlots;
      this.f.slots.setValue(this.avilableSlots);
      }


onSubmit() {
    this.submitted = true;   
    if (this.ManageAppointment.invalid) {
        return;
    }

    console.log(this.ManageAppointment.value);

    if(this.ManageAppointment.value['_id'] == null){

      this.addNewSlot = {
      emp_name: this.ManageAppointment.value['emp_name'],
      manage_date: this.ManageAppointment.value['manage_date'],
      manage_session: this.ManageAppointment.value['manage_session'],
      manage_timefrom: this.ManageAppointment.value['manage_timefrom'],
      fromampm: this.ManageAppointment.value['fromampm'],
      manage_timeTo: this.ManageAppointment.value['manage_timeTo'],
      toampm: this.ManageAppointment.value['toampm'],
      manage_interval: this.ManageAppointment.value['manage_interval'],
      slots: this.ManageAppointment.value['slots'],
    }
      
      console.log("values",this.ManageAppointment)
      
      this.mainServiceService.postManageAppointment(this.addNewSlot,).subscribe((res) => {
      console.log("Cool",this.addNewSlot.value)
    });

    this.onReset()
    this.refreshSlots();
  }


  // else{
  //    this.mainServiceService.putServices(this.ManageAppointment.value).subscribe((res) => {
  //      console.log(this.ManageAppointment.value)
  //      this.onReset();
  //    });
  //    this.onReset()
  //  }

  }
    


timegenerate(starth,startm,endh,endm,interval)
    {
      console.log("Accepted: ", starth , startm , endh , endm , interval);
        this.times=[]
        this.size= endh>starth ? endh-starth+1 : starth-endh+1
        this.hours=[...Array(this.size).keys()].map(i => i + starth);
        for (this.hour in this.hours)
        {
          
            for (this.min = startm; this.min < 60; this.min += interval) 
            {
                startm=0
                if ((this.hours.slice(-1)[0] === this.hours[this.hour]) && (this.min > endm))
                {
                    break;
                }
                if (this.hours[this.hour] > 11 && this.hours[this.hour] !== 24 )
                {
                  this.times.push(('0' + (this.hours[this.hour]%12 === 0 ? '12': this.hours[this.hour]%12)).slice(-2) + ':' + ('0' + this.min).slice(-2) + " " + 'PM');
                }
                else
                {
                  this.times.push(('0' +  (this.hours[this.hour]%12 === 0 ? '12': this.hours[this.hour]%12)).slice(-2) + ':' + ('0' + this.min).slice(-2) + " " + 'AM');
                }
            }
        }
        return this.times
    }



onReset() {
    this.submitted = false;
    this.ManageAppointment.reset();
}


}
