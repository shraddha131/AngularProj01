import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MainServiceService } from '../Shared/main-service.service';
import { Service } from '../Shared/service.model';
import { Employee } from '../Shared/employee.model';


@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css'],
  providers:[MainServiceService]
})
export class AddEmployeeComponent implements OnInit {

  addEmployee:FormGroup;
  submitted = false;
  emailPattern:any;
  allServices:any;
  Service: any[];
  addNewEmployee:any;

  constructor(private formBuilder : FormBuilder , public mainServiceService : MainServiceService  ) { }

  ngOnInit(): void {
    this.emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";

    this.addEmployee = this.formBuilder.group({
      _id:[],
      emp_name:['',[Validators.required,Validators.minLength(3)]],
      emp_phone:['',[Validators.required,Validators.minLength(10)]],
      emp_edu:['',[Validators.required]],
      emp_email:['', [Validators.required, Validators.email,Validators.pattern(this.emailPattern)]],
      emp_addr:['',[Validators.required,Validators.minLength(3)]],
      s_name:['',[Validators.required,Validators.minLength(3)]]
    });

    this.refreshEmployeeList();
    this.onReset();
  }

  get f() { return this.addEmployee.controls; }

  onSubmit() {
    this.submitted = true;
    
    if (this.addEmployee.invalid) {
        return;
    }

    if(this.addEmployee.value['_id'] == null){

      this.addNewEmployee = { emp_name: this.addEmployee.value['emp_name'], emp_phone: this.addEmployee.value['emp_phone'],emp_edu: this.addEmployee.value['emp_edu'], emp_email: this.addEmployee.value['emp_email'],emp_addr: this.addEmployee.value['emp_addr'], s_name: this.addEmployee.value['s_name']}
      console.log("values",this.addNewEmployee)
      
      this.mainServiceService.postEmployee(this.addNewEmployee,).subscribe((res) => {
      console.log(this.addEmployee.value)
    });

    this.onReset()
     }
  else{
     this.mainServiceService.putServices(this.addEmployee.value).subscribe((res) => {
       console.log(this.addEmployee.value)
       this.onReset();
     });
     this.onReset()
   }

  }


  refreshEmployeeList(){
      this.mainServiceService.getServicesList().subscribe((res) => {
      this.Service = this.mainServiceService.allServices = res as Service[];
      console.log(this.Service);
     });
  }

  onReset() {
    this.submitted = false;
    this.addEmployee.reset();
}
}
