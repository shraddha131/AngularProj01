const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const { mongoose } = require('./db.js');


var serviceController = require('./controllers/serviceController');
var employeeController = require('./controllers/employeeController');
var manageAppController = require('./controllers/manageAppController');
var adminController = require('./controllers/adminController');
var appointmentController =require('./controllers/appointments');

var app = express();
app.use(bodyParser.json());

app.use(cors({ origin: '*' }));

app.listen(3000, () => console.log('Server started at port : 3000'));



app.use('/service' , serviceController);
app.use('/employee' , employeeController);
app.use('/manageAppointment',manageAppController);
app.use('/admin',adminController);
app.use('/appointments',appointmentController);