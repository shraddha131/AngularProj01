const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;

var { ManageSlots } = require('../models/manageAppointment');


// => localhost:3000/manageAppointment

router.get('/',(req,res) => {
    ManageSlots.find((err,docs) =>{
        if(!err){ res.send(docs); }
        else { console.log('Error in Retriving Service :' + JSON.stringify(err, undefined, 2)); }
    }).sort({'_id':-1});
});

router.get('/slot/:emp_name', (req, res) => {
    ManageSlots.find({emp_name : req.params.emp_name} ,{slots:'',manage_date:'',manage_session:''},(err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving Slotmanagement :' + JSON.stringify(err, undefined, 2)); }
    });
});



router.get('/slots/:emp_name&:manage_date', (req, res) => {
    
    ManageSlots.find({ emp_name : req.params.emp_name, manage_date: req.params.manage_date},(err, docs) => {
        
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving subscription :' + JSON.stringify(err, undefined, 2)); }
    });
});


// router.get('/slots/date/:emp_name',(req,res)=>{
//     ManageSlots.distinct("manage_date",{emp_name:req.params.emp_name},(err,docs)=>{
            
//         if (!err) { res.send(docs); }
//         else { console.log('Error in Retriving subscription :' + JSON.stringify(err, undefined, 2)); }
//         });
// });






router.post('/',(req,res)=>{
    var mng = new ManageSlots({
        emp_name:req.body.emp_name,
        manage_date: req.body.manage_date,
        manage_session:req.body.manage_session,
        manage_timefrom:req.body.manage_timefrom,
        fromampm:req.body.fromampm,
        manage_timeTo:req.body.manage_timeTo,
        toampm:req.body.toampm,
        manage_interval:req.body.manage_interval,
        slots:req.body.slots
    });

    mng.save((err,docs) =>{
        if(!err){res.send(docs);}
        else{console.log('Error in Retriving Employee:' +JSON.stringify(err,undefined,2)); }
    });
});

// router.put('/:id', (req, res) => {
//     if (!ObjectId.isValid(req.params.id))
//         return res.status(400).send(`No record with given id : ${req.params.id}`);

//     var emp = {
//         emp_name:req.body.emp_name,
//         emp_email:req.body.emp_email,
//         emp_phone:req.body.emp_phone,
//         emp_addr: req.body.emp_addr,
//         emp_edu :req.body.emp_edu,
//         s_name : req.body.s_name,
//     };
//     Employee.findByIdAndUpdate(req.params.id, { $set: emp }, { new: true }, (err, doc) => {
//         if (!err) { res.send(doc); }
//         else { console.log('Error in subscription Service :' + JSON.stringify(err, undefined, 2)); }
//     });
// });


// router.delete('/:id', (req, res) => {
//     if (!ObjectId.isValid(req.params.id))
//         return res.status(400).send(`No record with given id : ${req.params.id}`);

//     Employee.findByIdAndRemove(req.params.id, (err, doc) => {
//         if (!err) { res.send(doc); }
//         else { console.log('Error in User Delete :' + JSON.stringify(err, undefined, 2)); }
//     });
// });


module.exports = router;
