const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;

var { Appointment } = require('../models/appointments');


// => localhost:3000/appointments

router.get('/',(req,res) => {
    Appointment.find((err,docs) =>{
        if(!err){ res.send(docs); }
        else { console.log('Error in Retriving appointment :' + JSON.stringify(err, undefined, 2)); }
    }).sort({'_id':-1});
});

router.get('/:_id', (req, res) => {
    Appointment.find({_id: req.params._id},(err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving appointment :' + JSON.stringify(err, undefined, 2)); }
    })
});

router.post('/',(req,res)=>{
    var apt = new Appointment({

        cust_name:req.body.cust_name,
        cust_phone:req.body.cust_phone,
        cust_email:req.body.cust_email,
        s_name:req.body.s_name,
        cust_specialist:req.body.cust_specialist,
        cust_date:req.body.cust_date,
        cust_slot:req.body.cust_slot,
    });

    apt.save((err,docs) =>{
        if(!err){res.send(docs);}
        else{console.log('Error in Retriving Appointment:' +JSON.stringify(err,undefined,2)); }
    });
});







module.exports = router;
