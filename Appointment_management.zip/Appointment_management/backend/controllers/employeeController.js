const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;

var { Employee } = require('../models/employee');


// => localhost:3000/employee

router.get('/',(req,res) => {
    Employee.find((err,docs) =>{
        if(!err){ res.send(docs); }
        else { console.log('Error in Retriving Service :' + JSON.stringify(err, undefined, 2)); }
    }).sort({'_id':-1});
});

router.get('/:_id', (req, res) => {
    Employee.find({_id: req.params._id},(err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving Super Admin :' + JSON.stringify(err, undefined, 2)); }
    })
});

router.post('/',(req,res)=>{
    var emp = new Employee({
        emp_name:req.body.emp_name,
        emp_email:req.body.emp_email,
        emp_phone:req.body.emp_phone,
        emp_addr: req.body.emp_addr,
        emp_edu :req.body.emp_edu,
        s_name : req.body.s_name,
    });

    emp.save((err,docs) =>{
        if(!err){res.send(docs);}
        else{console.log('Error in Retriving Employee:' +JSON.stringify(err,undefined,2)); }
    });
});


router.get('/service/:s_name',(req,res)=>{
    Employee.distinct("emp_name",{s_name:req.params.s_name},(err,docs)=>{
                if (!err) { res.send(docs); }
         else { console.log('Error in Retriving subscription :' + JSON.stringify(err, undefined, 2)); }
         });
});

router.put('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    var emp = {
        emp_name:req.body.emp_name,
        emp_email:req.body.emp_email,
        emp_phone:req.body.emp_phone,
        emp_addr: req.body.emp_addr,
        emp_edu :req.body.emp_edu,
        s_name : req.body.s_name,
    };
    Employee.findByIdAndUpdate(req.params.id, { $set: emp }, { new: true }, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in subscription Service :' + JSON.stringify(err, undefined, 2)); }
    });
});


router.delete('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    Employee.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in User Delete :' + JSON.stringify(err, undefined, 2)); }
    });
});


module.exports = router;
