const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;

var { Service } = require('../models/service');

// => localhost:3000/service
router.get('/', (req, res) => {
    Service.find((err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving Service :' + JSON.stringify(err, undefined, 2)); }
    }).sort({'_id':-1});
});



router.post('/', (req, res) => {
    var srv = new Service({
        s_name: req.body.s_name,
        s_desc: req.body.s_desc,
       
    });
    srv.save((err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Service Save :' + JSON.stringify(err, undefined, 2)); }
    });
});




router.put('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    var srv = {
        s_name: req.body.s_name,
        s_desc: req.body.s_desc,
      
        
    };
    Service.findByIdAndUpdate(req.params.id, { $set: srv }, { new: true }, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in subscription Service :' + JSON.stringify(err, undefined, 2)); }
    });
});


router.delete('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    Service.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in User Delete :' + JSON.stringify(err, undefined, 2)); }
    });
});



module.exports = router;
