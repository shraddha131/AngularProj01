const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;
const jwt = require('jsonwebtoken');
const bcryptjs = require("bcryptjs");
var { User } = require('../models/admin');
const authorize = require("../middlewares/auth");
const { check, validationResult } = require('express-validator');

// => localhost:3000/admin
router.get('/', (req, res) => {
    User.find((err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving User :' + JSON.stringify(err, undefined, 2)); }
    }).sort({'_id':-1});
});



router.get('/:email', (req, res) => {
    User.find({email: req.params.email},(err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving Super Admin :' + JSON.stringify(err, undefined, 2)); }
    }).sort({'_id':-1});
});


router.get('/user/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

        User.findById(req.params.id, (err, doc) => {
        if (!err) {
            res.send(doc);
        } else {
            console.log('Error in Retriving User :' + JSON.stringify(err, undefined, 2));
        }
    });
});


//login
router.post("/signin", (req, res, next) => {
    let getUser;
    User.findOne({
        user_id: req.body.user_id
    }).then(user => {
        if (!user) {
            return res.status(401).json({
                message: "Authentication failed !"
            });
        }
        getUser = user;
        return (req.body.password === user.password);
    }).then(response => {
        if (!response) {
            return res.status(401).json({
                message: "Authentication failed !!"
            });
        }
        let jwtToken = jwt.sign({
            email: getUser.email,
            userId: getUser._id
        }, "longer-secret-is-better", {
            expiresIn: "1h"
        });
        res.status(200).json({
            token: jwtToken,
            expiresIn: 3600,
            _id: getUser._id
        });
    }).catch(err => {
        return res.status(401).json({
            message: "Authentication failed !!!"
        });
    });
});


router.post('/', (req, res) => {
    var suprAdm = new User({

        user_id: req.body.user_id,
        email: req.body.email,
        phone:req.body.phone,
        password: req.body.password,
        
    });
    suprAdm.save((err, doc) => {
        if (!err) {
            res.send(doc);
        } else {
            console.log('Error in Company Save :' + JSON.stringify(err, undefined, 2));
        }
    });
});

router.get('/customer/:user_id',(req,res)=>{
        User.find({user_id:req.params.user_id},{email:'',phone:''},(err,docs)=>{
                    if (!err) { res.send(docs); }
             else { console.log('Error in Retriving subscription :' + JSON.stringify(err, undefined, 2)); }
             });
    });
    

router.put('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    var suprAdm = {
        user_id: req.body.user_id,
        email: req.body.email,
        phone:req.body.phone,
        password: req.body.password,
      
        
    };
    User.findByIdAndUpdate(req.params.id, { $set: suprAdm }, { new: true }, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in subscription User :' + JSON.stringify(err, undefined, 2)); }
    });
});

module.exports = router;
