const mongoose = require('mongoose');

var Employee = mongoose.model('Employee',{
    emp_name:{ type : String },
    emp_email: { type : String , unique : true },
    emp_phone:{ type : String , unique : true},
    emp_addr: { type : String },
    emp_edu : { type : String },
    s_name : { type : String }
});

module.exports = { Employee };