const mongoose = require('mongoose');

var Service = mongoose.model('Service', {
   
    s_name: { type: String ,unique: true },
    s_desc: { type: String }
});

module.exports = { Service };
