const mongoose = require('mongoose');

var Appointment = mongoose.model('Appointment',{
      cust_name:{ type : String },
      cust_phone:{ type : String },
      cust_email:{ type : String },
      s_name:{ type : String },
      cust_specialist:{ type : String },
      cust_date:{ type : String },
      cust_slot:{ type : String },
});

module.exports = { Appointment };