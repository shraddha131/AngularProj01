const mongoose = require('mongoose');

var User = mongoose.model('User', {
    user_id: { type: String },
    email: { type: String,unique: true },
    password: { type: String },
    key:{ type: String},
    phone:{type : String}
});

module.exports = { User };