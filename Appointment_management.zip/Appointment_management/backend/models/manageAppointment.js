const mongoose = require('mongoose');

var ManageSlots = mongoose.model('ManageSlots', {
   
    emp_name: { type: String},
    // manage_date: [{ year: String,
    //                 month:String,
    //             day:String }],
    manage_date :{ type : String },
    manage_session:{ type:String },
    manage_timefrom:{ type:String },
    fromampm:{ type : String},
    manage_timeTo:{ type : String },
    toampm:{ type : String },
    manage_interval:{ type : String },
    slots:[{ type : String }]

});

module.exports = { ManageSlots };
